/**
 * @properties={type:12,typeid:36,uuid:"BEF46A0D-74E4-4855-AA4E-7823FDC88EE3"}
 */
function demo()
{
	return '';
}
