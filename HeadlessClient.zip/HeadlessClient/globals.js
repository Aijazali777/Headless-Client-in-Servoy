/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"6163F391-940E-40E7-865D-921C3F4C4C0A"}
 */
var detail1 = "";
/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"2F8F7290-92BB-4AF3-86AC-0ACE82CEE183"}
 */
var detail2 = "";
/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"D7130CA5-7B89-4DC4-97E3-7E1212DB1866"}
 */
var detail3 = " ";
/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"C2F39FEA-BB79-4D65-B334-E07EF1C9B32E"}
 */
var detail4 = " ";
/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"A2897E63-A82D-4AC3-A612-DDA397553343"}
 */
var detail5 = " ";
/**
 * @properties={typeid:24,uuid:"F2CBC582-B99E-4480-99B4-81D9F27AF98A"}
 */
function HC1()
{
		/** @type {QBSelect<db:/example_data/headlessclient>} */
		var query = databaseManager.createSelect('db:/example_data/headlessclient');
		query.result.addPk();
		query.where.add(query.columns.clientname.eq("user1"))
		/**@type {JSFoundSet<db:/example_data/headlessclient>} */
		var customersFS = databaseManager.getFoundSet(query);
		customersFS.status = "Running";
		
		application.output(customersFS);
		while(customersFS.status == "Running")
		{
			application.sleep(1000);
			customersFS.times = application.getTimeStamp();
			
			databaseManager.saveData(customersFS);
			databaseManager.refreshRecordFromDatabase(customersFS,0);
			detail1= customersFS.clientid+" "+customersFS.clientname+" "+customersFS.status;
			application.output(detail1);
		}
}

/**
 * TODO generated, please specify type and doc for the params
 * 
 *
 * @properties={typeid:24,uuid:"D47D1AA5-525B-4043-9E6E-DD59DCDF9A8F"}
 */
function HC2()
{
	/** @type {QBSelect<db:/example_data/headlessclient>} */
	var query = databaseManager.createSelect('db:/example_data/headlessclient');
	query.result.addPk();
	query.where.add(query.columns.clientname.eq("user2"))
	/**@type {JSFoundSet<db:/example_data/headlessclient>} */
	var customersFS = databaseManager.getFoundSet(query);
	customersFS.status = "Running";
	
	application.output(customersFS);
	while(customersFS.status == "Running")
	{
		application.sleep(1000);
		customersFS.times = application.getTimeStamp();
		
		databaseManager.saveData(customersFS);
		databaseManager.refreshRecordFromDatabase(customersFS,0);
		detail2= customersFS.clientid+" "+customersFS.clientname+" "+customersFS.status;
		application.output(detail2);
	}
}

/**
 * TODO generated, please specify type and doc for the params
 *
 *
 * @properties={typeid:24,uuid:"18FC05C2-97B4-458B-AE23-E3A0EF222201"}
 */
function HC3()
{
	/** @type {QBSelect<db:/example_data/headlessclient>} */
	var query = databaseManager.createSelect('db:/example_data/headlessclient');
	query.result.addPk();
	query.where.add(query.columns.clientname.eq("user3"))
	/**@type {JSFoundSet<db:/example_data/headlessclient>} */
	var customersFS = databaseManager.getFoundSet(query);
	customersFS.status = "Running";
	
	application.output(customersFS);
	while(customersFS.status == "Running")
	{
		application.sleep(1000);
		customersFS.times = application.getTimeStamp();
		
		databaseManager.saveData(customersFS);
		databaseManager.refreshRecordFromDatabase(customersFS,0);
		detail3= customersFS.clientid+" "+customersFS.clientname+" "+customersFS.status;
		application.output(detail3);
	}
}
/**
 * TODO generated, please specify type and doc for the params
 * 
 *
 * @properties={typeid:24,uuid:"FCD2F6F8-CE44-45AC-A0DF-69BB5C5FF757"}
 */
function HC4()
{
	/** @type {QBSelect<db:/example_data/headlessclient>} */
	var query = databaseManager.createSelect('db:/example_data/headlessclient');
	query.result.addPk();
	query.where.add(query.columns.clientname.eq("user4"))
	/**@type {JSFoundSet<db:/example_data/headlessclient>} */
	var customersFS = databaseManager.getFoundSet(query);
	customersFS.status = "Running";
	
	application.output(customersFS);
	while(customersFS.status == "Running")
	{
		application.sleep(1000);
		customersFS.times = application.getTimeStamp();
		
		databaseManager.saveData(customersFS);
		databaseManager.refreshRecordFromDatabase(customersFS,0);
		detail4= customersFS.clientid+" "+customersFS.clientname+" "+customersFS.status;
		application.output(detail4);
	}
}

/**
 * TODO generated, please specify type and doc for the params
 * @param count
 *
 * @properties={typeid:24,uuid:"F7AB6C1C-6261-4ED6-98ED-9AE08263AA1E"}
 */
function HC5(count)
{
	/** @type {QBSelect<db:/example_data/headlessclient>} */
	var query = databaseManager.createSelect('db:/example_data/headlessclient');
	query.result.addPk();
	query.where.add(query.columns.clientname.eq("user5"))
	/**@type {JSFoundSet<db:/example_data/headlessclient>} */
	var customersFS = databaseManager.getFoundSet(query);
	customersFS.status = "Running";
	
	application.output(customersFS);
	while(customersFS.status == "Running")
	{
		application.sleep(1000);
		customersFS.times = application.getTimeStamp();
		
		databaseManager.saveData(customersFS);
		databaseManager.refreshRecordFromDatabase(customersFS,0);
		detail5= customersFS.clientid+" "+customersFS.clientname+" "+customersFS.status;
		application.output(detail5);
	}
}

/**
 * TODO generated, please specify type and doc for the params
 * @param event
 * @param client
 *
 * @properties={typeid:24,uuid:"6A5B5195-C3CC-42C0-B462-CD384311E30C"}
 */
function callBack(event, client)
{
}
