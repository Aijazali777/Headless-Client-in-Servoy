
/**
 * @type {plugins.headlessclient.JSClient}
 *
 * @properties={typeid:35,uuid:"A04849B5-ACB8-4DC1-8074-7A8144900EF5",variableType:-4}
 */
var headlessClient ;

/**
 * @type {Number}
 *
 * @properties={typeid:35,uuid:"7B51590A-714C-47F6-915B-1D0EE4FA9027",variableType:4}
 */
var c_id1;
/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"0B54B32B-7A2E-4331-B860-FDB3B1AA52B5"}
 */
var timeStam ;

/**
 * @type {Number}
 *
 * @properties={typeid:35,uuid:"7231EEA0-FB35-49FE-B289-1417EA366663",variableType:4}
 */
var num = 0;

/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"48309024-5F53-4F99-A3AE-E797D7AA14F7"}
 */
var logText = '';
/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"1A20C48A-91C1-4EAC-B11E-C161D1DDC0EB"}
 */
var clientID1;

/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"A30BFC8A-595B-4E6D-A61D-1DB2B222BC69"}
 */
var clientID2;
/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"E382D2F4-434C-412F-8D2F-08560CE4BD52"}
 */
var clientID3;
/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"ACCF3D1E-84CE-48CA-9D64-D90571D31829"}
 */
var clientID4;
/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"F9BA2BCA-AB6B-4737-95F2-E29F4DF4B447"}
 */
var clientID5;

/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"5A30B511-0751-47EB-9A18-192303432EDB"}
 */
var clientName2;

/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"9761C311-4433-47DE-88E8-FD23E231B62C"}
 */
var clientName1;
/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"8AB48046-73FA-4262-931E-75233408D69E"}
 */
var clientName3;
/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"AF7DBE0E-85D2-4AA1-9E39-7A551FE9D1EC"}
 */
var clientName4;
/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"E5937C96-A29C-41B4-A5CD-2BA1E93DBBFF"}
 */
var clientName5;

/**
 * @type {Date}
 *
 * @properties={typeid:35,uuid:"861EA850-EBCB-49D6-8527-C90444CD1305",variableType:93}
 */
var start_time;

/**
 * @type {Date}
 *
 * @properties={typeid:35,uuid:"9BB9B89D-C9B1-4AD0-84EF-52034CC87FB5",variableType:93}
 */
var start_time2;
/**
 * @type {Date}
 *
 * @properties={typeid:35,uuid:"95013433-93D1-447B-ABA2-5B12BCB421E2",variableType:93}
 */
var start_time3;
/**
 * @type {Date}
 *
 * @properties={typeid:35,uuid:"E9873355-CBA2-47C9-B13E-EB7977E897EE",variableType:93}
 */
var start_time4;
/**
 * @type {Date}
 *
 * @properties={typeid:35,uuid:"7058A058-D898-4606-ABB1-2E04D37F91AD",variableType:93}
 */
var start_time5;
/**
 * @param {JSEvent} event
 *
 * @properties={typeid:24,uuid:"286C7F42-0659-459D-A46D-2C7BCA91DEA2"}
 */
function createHC1(event)
{
	var headlessClient1 = plugins.headlessclient.createClient('HeadlessClient', 'user1', 'test1',["client","user1","test1","nodebug"]);
	start_time = application.getTimeStamp();
	
	var theQuery = "select clientname from headlessclient where clientname = 'user1'";
	var theDataset = databaseManager.getDataSetByQuery(databaseManager.getDataSourceServerName(controller.getDataSource()), theQuery, null, -1);
	//application.output(theDataset.getValue(1,1));
	
	if(theDataset.getValue(1,1))
	{
		clientID1 = headlessClient1.getClientID();
		foundset.getRecord(1).clientid = clientID1;
		//foundset.getRecord(1).status = "Running";
		foundset.getRecord(1).starttime = start_time;
		
		if (headlessClient1 != null && headlessClient1.isValid())
		{
			headlessClient1.queueMethod(null,"HC1",null,scopes.globals.callBack);
		}
	}
	else
	{
	
		foundset.newRecord();
		foundset.starttime = start_time;
		
		clientID1 = headlessClient1.getClientID();
		foundset.clientid = clientID1;

		clientName1 = "user1";
		foundset.clientname = clientName1;
		
		//foundset.status = "Running";
		
		databaseManager.saveData(foundset);
		
		if (headlessClient1 != null && headlessClient1.isValid())
		{
				headlessClient1.queueMethod(null,"HC1",null,scopes.globals.callBack);
		}
	}
}

/**
 * TODO generated, please specify type and doc for the params
 * @param event
 *
 * @properties={typeid:24,uuid:"71DBB2C1-93E1-4939-90E7-1F4AB7442454"}
 */
function createHC2(event)
{
	var headlessClient2 = plugins.headlessclient.createClient('HeadlessClient', 'user2', 'test2',["client","user2","test2","nodebug"]);
	start_time = application.getTimeStamp();
	
	var theQuery = "select clientname from headlessclient where clientname = 'user2'";
	var theDataset = databaseManager.getDataSetByQuery(databaseManager.getDataSourceServerName(controller.getDataSource()), theQuery, null, -1);
	//application.output(theDataset.getValue(1,1));
	
	if(theDataset.getValue(1,1))
	{
		clientID1 = headlessClient2.getClientID();
		foundset.getRecord(1).clientid = clientID2;
		//foundset.getRecord(1).status = "Running";
		foundset.getRecord(1).starttime = start_time;
		
		if (headlessClient2 != null && headlessClient2.isValid())
		{
			headlessClient2.queueMethod(null,"HC2",null,scopes.globals.callBack);
		}
	}
	else
	{
	
		foundset.newRecord();
		foundset.starttime = start_time;
		
		clientID2 = headlessClient2.getClientID();
		foundset.clientid = clientID2;

		clientName2 = "user2";
		foundset.clientname = clientName2;
		
		//foundset.status = "Running";
		
		databaseManager.saveData(foundset);
		if (headlessClient2 != null && headlessClient2.isValid())
		{
				headlessClient2.queueMethod(null,"HC2",null,scopes.globals.callBack);
		}
	}
}

/**
 * TODO generated, please specify type and doc for the params
 * @param event
 *
 * @properties={typeid:24,uuid:"4ECA5F2B-B720-4D8C-B084-81951434122E"}
 */
function createHC3(event)
{
	var headlessClient3 = plugins.headlessclient.createClient('HeadlessClient', 'user3', 'test3',["client","user3","test3","nodebug"]);
	start_time = application.getTimeStamp();
	
	var theQuery = "select clientname from headlessclient where clientname = 'user3'";
	var theDataset = databaseManager.getDataSetByQuery(databaseManager.getDataSourceServerName(controller.getDataSource()), theQuery, null, -1);
//	application.output(theDataset.getValue(1,1));
	
	if(theDataset.getValue(1,1))
	{
		clientID3 = headlessClient3.getClientID();
		foundset.getRecord(1).clientid = clientID3;
	//	foundset.getRecord(1).status = "Running";
		foundset.getRecord(1).starttime = start_time;
		
		if (headlessClient3 != null && headlessClient3.isValid())
		{
			headlessClient3.queueMethod(null,"HC3",null,scopes.globals.callBack);
		}
	}
	else
	{
	
		foundset.newRecord();
		foundset.starttime = start_time;
		
		clientID3 = headlessClient3.getClientID();
		foundset.clientid = clientID3;

		clientName3 = "user3";
		foundset.clientname = clientName3;
		
		databaseManager.saveData(foundset);
		if (headlessClient3 != null && headlessClient3.isValid())
		{
				headlessClient3.queueMethod(null,"HC3",null,scopes.globals.callBack);
		}
	}
}

/**
 * TODO generated, please specify type and doc for the params
 * @param event
 *
 * @properties={typeid:24,uuid:"B1BBCC0D-99D1-40DD-98A2-38F30F37FEA2"}
 */
function createHC4(event)
{
	var headlessClient4 = plugins.headlessclient.createClient('HeadlessClient', 'user4', 'test4',["client","user4","test4","nodebug"]);
	start_time = application.getTimeStamp();
	
	var theQuery = "select clientname from headlessclient where clientname = 'user4'";
	var theDataset = databaseManager.getDataSetByQuery(databaseManager.getDataSourceServerName(controller.getDataSource()), theQuery, null, -1);
	//application.output(theDataset.getValue(1,1));
	
	if(theDataset.getValue(1,1))
	{
		clientID4 = headlessClient4.getClientID();
		foundset.getRecord(1).clientid = clientID4;
	//	foundset.getRecord(1).status = "Running";
		foundset.getRecord(1).starttime = start_time;
		
		if (headlessClient4 != null && headlessClient4.isValid())
		{
			headlessClient4.queueMethod(null,"HC4",null,scopes.globals.callBack);
		}
	}
	else
	{
	
		foundset.newRecord();
		foundset.starttime = start_time;
		
		clientID4 = headlessClient4.getClientID();
		foundset.clientid = clientID4;

		clientName4 = "user4";
		foundset.clientname = clientName4;
		
		databaseManager.saveData(foundset);
		if (headlessClient4 != null && headlessClient4.isValid())
		{
				headlessClient4.queueMethod(null,"HC4",null,scopes.globals.callBack);
		}
//		var a = 0
//		while(a<4){
//			var theQuery2 = "select clientname, status from headlessclient where clientname = 'user4'";
//			var theDataset2 = databaseManager.getDataSetByQuery(databaseManager.getDataSourceServerName(controller.getDataSource()), theQuery2, null, -1);
//			application.output(theDataset2);
//			application.sleep(1000)
//			a++
//		}
	}
}

/**
 * TODO generated, please specify type and doc for the params
 * @param event
 *
 * @properties={typeid:24,uuid:"AE878C09-4AB6-4176-8CF4-9775E95980A7"}
 */
function createHC5(event)
{
	var headlessClient5 = plugins.headlessclient.createClient('HeadlessClient', 'user5', 'test5',["client","user5","test5","nodebug"]);
	start_time = application.getTimeStamp();
	
	var theQuery = "select clientname from headlessclient where clientname = 'user5'";
	var theDataset = databaseManager.getDataSetByQuery(databaseManager.getDataSourceServerName(controller.getDataSource()), theQuery, null, -1);
//	application.output(theDataset.getValue(1,1));
	
	if(theDataset.getValue(1,1))
	{
		clientID5 = headlessClient5.getClientID();
		foundset.getRecord(1).clientid = clientID5;
	//	foundset.getRecord(1).status = "Running";
		foundset.getRecord(1).starttime = start_time;
		
		if (headlessClient5 != null && headlessClient5.isValid())
		{
			headlessClient5.queueMethod(null,"HC5",null,scopes.globals.callBack);
		}
	}
	else
	{
	
		foundset.newRecord();
		foundset.starttime = start_time;
		
		clientID5 = headlessClient5.getClientID();
		foundset.clientid = clientID5;
	
		clientName5 = "user5";
		foundset.clientname = clientName5;
		
		databaseManager.saveData(foundset);
		if (headlessClient5 != null && headlessClient5.isValid())
		{
				headlessClient5.queueMethod(null,"HC5",null,scopes.globals.callBack);
		}
	}
}



/**
 * @param {JSEvent} event
 *
 * @properties={typeid:24,uuid:"E51DBFAA-3125-4C54-9501-D5620CC9AD84"}
 */
function onStop(event)
{
	foundset.getSelectedIndex();
 	foundset.status = "Stopped";
 	databaseManager.saveData(foundset);
 	var hc = plugins.headlessclient.getClient(clientid)
	if(hc.isValid())
	{
		application.output(clientid);
	 	application.output(foundset.status);
	 	application.sleep(2000);
		hc.shutdown(true);
	}
}

/**
 * Called when the mouse is clicked on a row/cell (foundset and column indexes are given) or.
 * when the ENTER key is used then only the selected foundset index is given
 * Use the record to exactly match where the user clicked on
 *
 * @param {number} foundsetindex
 * @param {number} [columnindex]
 * @param {JSRecord} [record]
 * @param {JSEvent} [event]
 * @param {string} [columnid]
 *
 * @properties={typeid:24,uuid:"15903A88-B365-4026-87C6-CC17188BA3A9"}
 */
function onCellClick(foundsetindex, columnindex, record, event, columnid)
{
	if(columnid == 'btn_stop')
	{
		onStop(event);
	}
}

/**
 * @param {JSEvent} event
 *
 * @properties={typeid:24,uuid:"41945AF6-7F1D-4877-A08F-CA42DC044444"}
 */
function onDeleteAllRecords(event)
{
	controller.deleteAllRecords();
}

/**
 * @param {JSEvent} event
 *
 * @properties={typeid:24,uuid:"74BAF8E2-4B40-4791-A4C4-C728683E659E"}
 */
function onRefresh(event)
{
	var query = databaseManager.createSelect('db:/example_data/headlessclient');
	query.result.addPk()
	var dataSet = databaseManager.getDataSetByQuery(query,-1)
	application.output(dataSet)
	foundset.loadRecords(dataSet);
	application.updateUI();
}
